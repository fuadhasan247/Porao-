# porao_app

A new Flutter project.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [UX Design: Porate Chai](https://www.figma.com/file/4Y1pf8IUQO9aKgGfpjApQc/Evericons?type=design&node-id=281182%3A2&mode=design&t=8Eiz88cHU8BB7Mdu-1)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.
