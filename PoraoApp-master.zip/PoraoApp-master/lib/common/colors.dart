import 'package:porao_app/common/all_import.dart';

Color primaryColor = const Color.fromARGB(255, 82, 149, 236);
Color seconderyColor = const Color.fromARGB(255, 199, 214, 234);
Color primaryButtonColor = const Color.fromARGB(255, 166, 196, 235);
Color seconderyButtonColor = const Color.fromARGB(255, 151, 187, 234);
